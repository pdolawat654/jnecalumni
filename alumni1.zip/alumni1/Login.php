<?php
if(isset($_SESSION)){
	session_start();
    $username=$_SESSION['email'];
    if(!empty($username))
    {
      header('location:Home.php');
    }
   }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
	<style>
		 .head{
      background-color: indianred;
      color:white;
      padding: 5px;
      font-size: 17px;
      padding-left: 20px;
       font-weight: bold;
       position: relative;
    }
		.Register{
			background-color: papayawhip;
			width: 400px;
			height: 580px;
			font-size: 16px;	
			font-style: italic;	
			padding-bottom: 20px;
			 font-weight: bold;
			 	padding-top: 5px; 
		}
		input{
			border: 2px solid black;
			border-radius: 5px; 
			width: 200px;
			height: 30px;
		}
		 .Profile{
     border: 2px solid black;
      margin-top: 100px;
   		background-color: peachpuff; 
			width: 400px;
			font-size: 16px;	
			font-style: italic;	
			 font-weight: bold;
    }
	</style>
</head>
<body>
<center>
<div class="Profile">
		<center>
		<div class="head">Login</div>
		<form method="POST">
<pre style="font-size: 16px;"><br><br>
Email-ID : <input type="email" name="email"><br><br>

Password : <input type="Password" name="pass">
</pre>
<br><a href="Register.php" style="text-decoration: none;font-size: 20px;">Not registered?Register Now</a><br><br><br>
<input style="height: 30px;color:white;width: 100%;background-color:brown;border: none;border-radius:0px;cursor: pointer;" type="submit" name="Login">

</form>	


		</center>
</div>
</center>
</body>
</html>

<?php

if(isset($_POST['Login']))
{
	$conn=mysqli_connect("localhost","id13073284_test","Prashant1!","id13073284_test");
	$username=$_POST['email'];
	$password=$_POST['pass'];
			session_start();
			$_SESSION['email']=$username;
if($username=="alumnijnec@gmail.com" && $password=="jnec123")
	{
		header('location:admin.php');	
	}
else{
	$sql="select * from ainfo where email='$username' and pass='$password'";
	$res=mysqli_query($conn,$sql);
	  if(mysqli_num_rows($res)==1){
  
      while($ro=mysqli_fetch_assoc($res))
      { $i=$ro['v'];
        }
        if($i==1)
        {
	
	if(!$res)
	{
		die(mysql_error());
		}
	else
	{
		$count=mysqli_num_rows($res);
		
		if($count==1)
		{
			header('location: Home.php');
			}
			
		else
		{
			echo "Check your details";
			}
		
				
		}
	}
	else
	{
		header('location:Verify.php');
	}
	}

	}
}
?>