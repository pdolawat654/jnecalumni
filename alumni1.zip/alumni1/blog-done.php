 <?php	
			$conn=mysqli_connect("localhost","id13073284_test","Prashant1!","id13073284_test");
    		session_start();
    		$username=$_SESSION['email'];
			
    		$check = getimagesize($_FILES["image"]["tmp_name"]);
    		if($check !== false){
      	 	 $image = $_FILES['image']['tmp_name'];
       		 $imgContent = addslashes(file_get_contents($image));
			$blog=$_POST['blog'];
			$q="select * from inf where email='$username'";
			$rest=mysqli_query($conn,$q);
			if(mysqli_num_rows($rest)>0){
  
     		 while($ro=mysqli_fetch_assoc($rest))
     		{
       		 $n=$ro["aid"];
       		 $y=$ro['passout'];
       		 $branch=$ro['branch'];
       		}
       		}
		

			$sql = "INSERT INTO blogs(`aid`, `blog`, `flag`, `year`, `image`,`branch`) VALUES ('$n','$blog',1,'$y','$imgContent','$branch')";
			if(mysqli_query($conn,$sql))
			{
				if($username=='alumnijnec@gmail.com')
					header('location:admin.php');
				else
			header('location:Home.php');
			}

		}
		
?>