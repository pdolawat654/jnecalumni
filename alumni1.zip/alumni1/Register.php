<?php
if(isset($_SESSION)){
	session_start();
    $username=$_SESSION['email'];
    if(!empty($username))
    {
      header('location:Home.php');
    }
   }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
	<style>
		 .head{
      background-color: indianred;
      color:white;
      padding: 5px;
      font-size: 17px;
      padding-left: 20px;
       font-weight: bold;
       position: relative;
    }
		.Register{
			margin-top: 50px;
			 border: 2px solid black;
   		background-color: peachpuff; 
			width: 400px;
			font-size: 16px;	
			font-style: italic;	
			 font-weight: bold;
		}
		input{
			border: 2px solid black;
			border-radius: 5px; 
			width: 200px;
			height: 30px;
		}

	</style>
</head>
<body>
<center>
<div class="Register">
		<center>
	<div class="head">REGISTRATION</div>
		<form method="POST">
<pre style="font-size: 16px;">
Name 	 :   <input type="text" name="name"><br><br><br>
Phone 	 :   <input type="text" name="phone"><br><br><br>
Email-ID :   <input type="email" name="email"><br><br><br>
Password :   <input type="Password" name="pass"><br>

</pre>
	<a href="Login.php" style="text-decoration: none;font-size: 20px;">Already registered?Login</a>



<br>	
<input style="height: 40px;border: none;color:white;width: 100%;background-color:brown;border-radius: 0px;cursor: pointer;" type="submit" name="Register">
</form>	
		</center>
</div>
</center>
</body>
</html>
<?php
ob_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


if(isset($_POST['Register']))
{

$email=$_POST['email'];
$pass=$_POST['pass'];
$pass=trim($pass);
if(!(strlen($pass)>6 && strlen($pass)<16))
{
	echo "<script>alert('Password must be of length between 6 to 16')</script>";
}
$name=$_POST['name'];
$name=trim($name);
if(!(ctype_alpha($name) || strlen($name)>2))
{
	echo "<script>alert('Enter valid Name')</script>";	
}

$phone=$_POST['phone'];
$phone=trim($phone);
if(!($phone==""))
{
if(!($phone[0]==(6 || 7 || 8 || 9) && strlen($phone)==10))
{
		echo "<script>alert('Invalid Phone number')</script>";		
}
}
$otp=rand(100000,999999);
$conn=mysqli_connect("localhost","id13073284_test","Prashant1!","id13073284_test");

$sql2 = "select * from inf where email='$email'";
$re=mysqli_query($conn,$sql2);
if($ro=mysqli_num_rows($re)==0)
{
$sql = "INSERT INTO ainfo(`name`,`email`, `pass`, `otp`) VALUES ('$name','$email','$pass','$otp')";
$sql1 = "INSERT INTO inf(`name`,`email`,`phone`) VALUES ('$name','$email','$phone')";

require 'C:/Users/Prashant/vendor/autoload.php';
$mail = new PHPMailer(true);
try {
    //Server settings
    $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      // Enable verbose debug output
    $mail->isSMTP();                                            // Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = 'alumnijnec@gmail.com';                     // SMTP username
    $mail->Password   = 'jnec1234!';                               // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
    $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

    //Recipients
    $mail->setFrom('no-reply_jnecalumni@gmail.org', 'JNEC Alumni Cell');
    $mail->addAddress($email);     // Add a recipient
   
  
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'REGISTRATION SUCESSFUL';
    $mail->Body    = "<b>Thank you for registering at JNEC ALUMNI PORTAL!!!!</b><br><b>Your OTP is '$otp'</b>";
    //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    if (mysqli_query($conn,$sql) && mysqli_query($conn,$sql1))
 { 
 		//session_start();
	//	$_SESSION['phone']="91".$phone;   
	//	$_SESSION['otp']=$otp;   
    header('location:Login.php');
  }

else 
   {
        echo '<script>alert("Email-ID already exists")</script>';

    }
    
} catch (Exception $e) {
	 header('location:Register.php');
}

}
else
echo '<script>alert("Email-ID already exists")</script>';
mysqli_close($conn);
}
ob_flush();
?>