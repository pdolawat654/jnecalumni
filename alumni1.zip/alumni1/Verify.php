<?php
if(isset($_SESSION)){
    session_start();
    $username=$_SESSION['email'];
    if(!empty($username))
    {
      header('location:Home.php');
    }
     if($username=='alumnijnec@gmail.com')
    {
      header('location:admin.php');
    }
   }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Registration</title>
    <style>
        body{
        background-color: peachpuff; 
        }
        .Register{
            background-color: papayawhip;
            width: 400px;
            height: 580px;
            font-size: 16px;    
            font-style: italic; 
            padding-bottom: 20px;
             font-weight: bold;
                padding-top: 5px; 
        }
        input{
            border: 2px solid black;
            border-radius: 5px; 
            width: 200px;
            height: 30px;
        }

 	</style>
 </head>
 <body>
 	<center>
<div class="Register">
		<center>
		<h1>VERIFY OTP</h1><br>
		<form method="POST">
<pre style="font-size: 16px;">

<h1>ENTER OTP :</h1> <input type="text" name="otp"><br><br><br>

</pre>
<input style="height: 40px;display: inline-block;color:white;width: 120px;background-color:green;border-radius: 5px;" type="submit" name="s">

</form>	


		</center>
</div>
</center>

 </body>
 </html>
 <?php
$f=1;
    $conn=mysqli_connect("localhost","id13073284_test","Prashant1!","id13073284_test");
    session_start();
    $username=$_SESSION['email'];
    $sql="select * from ainfo where email='$username'";
    	$re=mysqli_query($conn,$sql);
    	while($ro=mysqli_fetch_assoc($re))
    	{
    		$i=$ro['otp'];
    		$v=$ro['v'];
    	}
    	if($v==1)
    	{
    		header('location:Home.php');
    	}
    if(isset($_POST['s']))
    {
    	
    	
    	if($i==(int)$_POST['otp'])
    	{
    		$insert = $conn->query("update ainfo SET v='$f' where email='$username'");
    		
    		if($insert)
    		header('location:Update.php');
    		else
    		echo "NHI HUA BHAI";
    	}
    	else
    	{
    		echo 'Incorrect OTP';
    		echo $ro;
    	}
    }
?>