<?php
    ob_start();
    $conn=mysqli_connect("localhost","id13073284_test","Prashant1!","id13073284_test");
    session_start();
    $username=$_SESSION['email'];

    if(empty($username))
    {
      header('location:Login.php');
    }
    
    $s="select * from inf where email='$username'";
    $re=mysqli_query($conn,$s);
      if(mysqli_num_rows($re)>0){
  
      while($ro=mysqli_fetch_assoc($re))
      {
        $n=$ro["name"];
        $id1=$ro['aid'];
        $yr=$ro['passout'];
?>
<!DOCTYPE html>
<html>
<head>
  <title>Home</title>
  <style>
    p{
      display: block;
    margin-block-start: 1em;
    margin-block-end: 1em;
    margin-inline-start: 0px;
    margin-inline-end: 0px;

    }
    #a1{
      display: inline-block;
    }
    .menu{
      top:0;
      left:0;
      margin: 0px;
      position: fixed;
      height: 7%;
      width: 100%;
      color:white;
      background-color: brown; 
    }
    .sb{
      margin-top: 36px;
      right:0;
      width: 300px;
      padding-bottom: 187px;
      position: fixed;
      background-color: peachpuff;
    }
    .inbox{
      left:0;
      bottom:0;
      background-color:peachpuff;
      width: 300px;
      height: 54%;
      position: fixed;
      overflow-y: auto;
    }
    .birthday{
      right:0;
      bottom:0;
      background-color:peachpuff;
      width: 300px;
      height: 53%;
      position: fixed;
      overflow-y: auto;
    }
    ::-webkit-scrollbar{
    display: none;
    }
        .Profile{
          width: 400px;
     border: 2px solid black;
     padding: 13px;
    }
    .leftmenu{
      left:0;
      background-color: peachpuff;
      width: 300px;
      margin-top: 36px;
      position: fixed;
      overflow-y: auto;
    }
    .blogimg{
      margin-left: 25px;
      height: 350px;
      width: 600px; 
    }
    .simg{
      height:50px;
      margin-top: 10px;
      margin-left:25px;
      width:50px;
      border-radius:25px;
    }
    .main{
      width: 57%;
      background-color:papayawhip; 
      overflow-y: auto;
      margin-top: 36px;
      margin-left: 292px;
      height: 93%;
      position: fixed;
      padding: 0px;
    }
    .blogcontent{
      overflow-y: hidden;
      align-content: center;
      background-color:lemonchiffon;
      border:1px solid darkred;
      padding: 10px;
      margin-left:25px;
      height: 60px;
      width: 575px;
      overflow: auto;
      font-size: 17px;
      font-style: italic;
      font-weight: bold;
    }
    button{
      background-color: brown;
      color:white;
      border: none;
      width: auto;
      margin: 5px;
      font-size: 16px;
      padding: 8px;
    }
    button:hover{
      background-color: red;
      cursor: pointer;
    }
    .sb{
      height: 10%;

    }
    td{
      font-size: 17px;
      font-style: italic;
      font-weight: bold;
      padding: 12px;
    }
    .search-box{
        width: 230px;
        position: relative;
        display: inline-block;
        font-size: 14px;
    }
    .head{
      background-color: indianred;
      color:white;
      padding: 5px;
      font-size: 17px;
      padding-left: 20px;
       font-weight: bold;
       position: relative;
    }
    .search-box input[type="text"]{
        height: 32px;
        width: 200px;
        padding: 5px 10px;
        border: 1px solid #CCCCCC;
        font-size: 14px;
    }
    .result{
        position: absolute;        
        z-index: 999;
        top: 100%;
        left: 0;
        background-color: white;
    }
    .search-box input[type="text"], .result{
        width: 100%;
        color: black;
        box-sizing: border-box;
    }
    /* Formatting result items */
    .result p{
        margin: 0;
        padding: 7px 10px;
        border: 1px solid #CCCCCC;
        border-top: none;
        cursor: pointer;
    }
    .minbox{
    width: 100%;
     font-size: 17px;
      font-style: italic;
      font-weight: bold;
      background-color: darksalmon;
      border: none;
      border-bottom: 1px solid brown;
      color: white;
      height: 30px;
    }
    .minbox:hover{
      cursor: pointer;
      background-color: darkred;
    }
     .result p:hover{
        background: #f2f2f2;
    }
    .smbtn{
      background-color: brown;
      width:60px;
      height: 30px;
      color:white;
      border:none;
    }

  </style>
    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $('.search-box input[type="text"]').on("keyup input", function(){
        /* Get input value on change */
        var inputVal = $(this).val();
        var resultDropdown = $(this).siblings(".result");
        if(inputVal.length){
            $.get("backend-search.php", {term: inputVal}).done(function(data){
                // Display the returned data in browser
                resultDropdown.html(data);
            });
        } else{
            resultDropdown.empty();
        }
    });
    
    // Set search input value on click of result item
    $(document).on("click", ".result p", function(){
        $(this).parents(".search-box").find('input[type="text"]').val($(this).text());
        $(this).parent(".result").empty();
    });
});
</script>
</head>
<body>
    <div class="menu">
      <button style="width:280px;"><?php echo $n; ?></button>
      <button onClick="blogs()">Home</button>
      <button onClick="news()">News</button>      
      <button onClick="contact()">Search</button>
      <button onClick="log()" style="float: right;">Logout</button>
      <button onClick="pro()" style="float: right;">Profile</button>
    </div>
  <div class="leftmenu">
    <?php 
        if(empty($ro['image']))
         echo '<center><img src="123.jpg" style="margin:22px;height:200px;width:200px;border-radius:100px;"/></center>';
        else
        echo '<center><img src="data:image/jpeg;base64,'.base64_encode( $ro['image'] ).'" style="margin:22px;height:200px;width:200px;border-radius:100px;"/></center>';
        }
  }
  else{
    echo "0 results";
  }
  ?>

  </div>

    <div class='main'>
    <center>  <div class="Profile">
     
    <form method="post" enctype="multipart/form-data">
        
<?php
 
    $s="select * from inf where email='$username'";
    $re=mysqli_query($conn,$s);
      if(mysqli_num_rows($re)>0){
  
      while($ro=mysqli_fetch_assoc($re))
      {
        $i=$ro['aid'];
        $n=$ro["name"];
        $e=$ro["email"];
        $p=$ro["phone"];
        $b=$ro["branch"];
        $pas=$ro["passout"];
        $w=$ro["working"];
        $r=$ro["relation"];
        ?>
<table>
          <div class='head'><?php echo $n; ?></div>    
        <tr><?php if(empty($ro['image']))
        echo "<img src='123.jpg' style='height:250px;width:250px;border-radius:125px;'/>";
        else
        echo '<img src="data:image/jpeg;base64,'.base64_encode( $ro['image'] ).'" style="height:250px;width:250px;border-radius:125px;"/>';
        }
  }
  else{
    echo "0 results";
  }
  ?>
<tr><td>Select image to upload:</td><td><input type="file" name="image" required/></td></tr>
        <tr><td>Email ID :</td><td><?php echo $e; ?></td></tr>
        <tr><td>Phone :</td><td><?php echo $p; ?></td></tr>
        <tr><td>Branch :</td><td>
            <select name="branch">
    <option value="CSE">CSE</option>
    <option value="MECH">MECH</option>
    <option value="IT">IT</option>
    <option value="EEP">EEP</option>
    <option value="ENTC">ENTC</option>
    <option value="ARCH">ARCH</option>
    <option value="MCA">MCA</option>
    <option value="INST">INST</option>
    <option value="PROD">PROD</option>
    <option value="CHEM">CHEM</option>
      </select></tr>
      <tr><td>Passout Year:</td><td>
          <select name="passout">
<?php
for ($y=1980; $y<=2020 ; $y++) { ?>
    <option value="<?php echo $y; ?>"><?php echo $y; ?></option>
<?php } ?>
</select>
        </td></tr>
      <tr><td>Date of Birth:</td><td>
          <select name="d">
<?php
for ($y=1; $y<=31 ; $y++) { ?>
    <option value="<?php echo $y; ?>"><?php echo $y; ?></option>
<?php } ?>
</select>
 <select name="m">
    <option value="January">January</option>
    <option value="February">February</option>
    <option value="March">March</option>
    <option value="April">April</option>
    <option value="May">May</option>
    <option value="June">June</option>
    <option value="July">July</option>
    <option value="August">August</option>
    <option value="September">September</option>
    <option value="October">October</option>
    <option value="November">November</option>
    <option value="December">December</option>
      </select>
               <select name="y">
<?php
for ($y=1950; $y<=2020 ; $y++) { ?>
    <option value="<?php echo $y; ?>"><?php echo $y; ?></option>
<?php } ?>
</select>
        </td></tr>

        
  
        <tr><td>Working at :</td><td><input type="text" name="work" value="<?php echo $w; ?>" required/></td></tr>
        <tr><td>Relationship Status:</td><td>
          <select name="relation">
    <option value="Single">Single</option>
    <option value="Married">Married</option>
    
      </select>
      </table>
       
        <input style="height: 40px;width: 180px;color: white;background-color: green;margin-bottom: 10px;" type="submit" name="upload" value="UPLOAD"/>
    </form>
    <?php

if(isset($_POST["upload"])){
 
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if($check !== false){
        $image = $_FILES['image']['tmp_name'];
        $imgContent = addslashes(file_get_contents($image));
        $br=$_POST['branch'];
        $pa=$_POST['passout'];
        $d=$_POST['d'];
        $m=$_POST['m'];
        $m=$_POST['m'];
        $dob=$d." ".$m." ".$y;
        $wo=$_POST['work'];
        $re=$_POST['relation'];
      
 
      
        $insert = $conn->query("update inf SET image='$imgContent',branch='$br',dob='$dob',passout='$pa',working='$wo',relation='$re' where email='$username'");
        if($insert){
            header('location:Home.php');
            echo "File uploaded successfully.";
        }else{
            echo "File upload failed, please try again.";
        } 
    }else{
        echo "Please select an image file to upload.";
    }
   
}
?>
  </div>
</center>
     </div>
<div class="sb">
        <center><div class='head'>Search</div></center>
        <div class="search-box">
        <form action="A1.php" method="POST">
        <input type="text" autocomplete="off" placeholder="Search your batchmates..." name="name" />
        <div class="result"></div>
        </div>
        <input class="smbtn" type='submit' value="Search">
        </form>
    <div class="head">BIRTHDAY'S</div> 
<div style="overflow-y: auto;height: 160px;"> 

  <?php
  $mydate=getdate(date("U"));
$h=$mydate['mday']."-".$mydate['month'];
$bsql="select * from inf except (select * from inf where aid='$id1')";
$r=mysqli_query($conn,$bsql);
while($ro=mysqli_fetch_assoc($r))
{
  $na=$ro['name'];
  $ai=$ro['aid'];
  $d1=$ro['dob'];
 $str_arr = explode (" ", $d1);
  $g="".$str_arr[0]."-".$str_arr[1]."";
  if($g==$h)
  {?>
    <form method="POST">
          <?php
          if(empty($ro['image']))
         echo "<img src='123.jpg' style='height:150px;width:150px;border-radius:75px;margin:10px;'/>";
        else
        echo '<center><img src="data:image/jpeg;base64,'.base64_encode( $ro['image'] ).'" style="margin:10px;height:150px;width:150px;border-radius:75px;"/></center>';
          echo "<input type='hidden' name='a' value='$ai'>";
          echo "<input class='minbox' style='margin-bottom:10px;' type='submit' name='sub2' value='Wish $na'>";
        ?></form><?Php
        
  }
}
        if(isset($_POST['sub2']))
        {
          $s14=$_POST['a'];
         $_SESSION['e2']=$s14;
        header('location:Amess1.php');
        }
        
        ?>
      </div>

<div class='inbox'>
<center><div class='head'>Inbox</div></center>
<?php
    $color=1;
     $s1="select distinct sender from chat where reciever='$id1' order by `mid` desc";
    
    $re1=mysqli_query($conn,$s1);
   
      if(mysqli_num_rows($re)>0){
  
      while($ro1=mysqli_fetch_assoc($re1))
      {
        $s2="select * from inf where aid=".$ro1['sender'];
       
          $re2=mysqli_query($conn,$s2);
   
      if(mysqli_num_rows($re2)>0){
        
      while($ro2=mysqli_fetch_assoc($re2))
       {
        $n3=$ro2['name'];
        $a=$ro2['aid'];
        ?>
       
         <form method="POST">
          <?php
          echo "<input type='hidden' name='a' value='$a'>";
          echo "<input class='minbox' type='submit' name='sub' value='$n3'>";
       }
       } ?>
         
      </table>
 
      </form>
   
        
<?php
       }
      }
      if(isset($_POST['sub']))
      {
         $s14=$_POST['a'];
         $_SESSION['e2']=$s14;
        header('location:Amess1.php');
      }
  
?>
</div>

<div class="birthday">
     
<center><div class="head" style="margin-top: 10px;">NOTIFICATIONS</div></center>
<div style="overflow-y: auto;height: 250px;"> 
  <?php
    $s='select * from news';
    $r=mysqli_query($conn,$s);
    while($ro=mysqli_fetch_assoc($r)){
        echo '<center><img src="data:image/jpeg;base64,'.base64_encode( $ro['image'] ).'" style="height:150px;width:250px;margin:5px;"/></center>';
        echo '<center><div class="head">'.$ro['news'].'</div></center>';
    }
  ?>
</div>
 </div>
  

</div>   
  
  

</body>
</html>
<script>

  function log(){
  location.href="index.php";
}
function pro(){
  location.href="AProfile.php";
}
function time(){
  location.href="ATimeline.php";
}
function blogs(){
  location.href="admin.php";
}
function news(){
  location.href="news.php";
}
function contact(){
  location.href="Search.php";
}
</script>
