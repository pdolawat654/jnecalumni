 <!DOCTYPE html>
<html>
<head>
	<title>Messages</title>
	<style>
		p{
			display: block;
    margin-block-start: 1em;
    margin-block-end: 1em;
    margin-inline-start: 0px;
    margin-inline-end: 0px;

		}
		  ::-webkit-scrollbar{
    display: none;
    }
    .top{
      color: darkblue;      
      margin: 0px;
      padding: 10px;
    }
    #a1{
      display: inline-block;
    }
   .menu{
      top:0;
      left:0;
      margin: 0px;
      position: fixed;
      height: 7%;
      width: 100%;
      color:white;
      background-color: brown; 
    }
		button{
      background-color: brown;
      color:white;
      border: none;
      width: auto;
      margin: 5px;
      font-size: 16px;
      padding: 8px;
    }
		button:hover{
			background-color: red;
			cursor: pointer;
		}
    .Profile{
     border: 2px solid black;
      margin-left: 380px;
      margin-right: 380px;
      margin-top: 100px;
    }
        td{    
           padding: 5px;   
           padding-right: 20px;
           font-size: 17px;
           font-style: italic;
           font-weight: bold;
    }
      .head{
      background-color: indianred;
      color:white;
      padding: 5px;
      font-size: 17px;
      padding-left: 20px;
       font-weight: bold;
       position: relative;
    }
	.search-box{
        width: 230px;
        position: relative;
        display: inline-block;
        font-size: 14px;
    }
    .search-box input[type="text"]{
        height: 32px;
        padding: 5px 10px;
        border: 1px solid #CCCCCC;
        font-size: 14px;

    }
    .result{
        position: absolute;        
        z-index: 999;
        top: 100%;
        left: 0;
        background-color: white;
    }
    .search-box input[type="text"], .result{
        width: 100%;
        color: black;
        box-sizing: border-box;
    }
    /* Formatting result items */
    .result p{
        margin: 0;
        padding: 7px 10px;
        border: 1px solid #CCCCCC;
        border-top: none;
        cursor: pointer;
    }
     .inbox{
      left:0;
      bottom:0;
      background-color:peachpuff;
      width: 300px;
      height: 54%;
      position: fixed;
      overflow-y: auto;
    }
     .birthday{
      right:0;
      top:0;
      margin-top: 44px;
      background-color:peachpuff;
      width: 300px;
      height: 53%;
      position: fixed;
      overflow-y: auto;
    }
     .result p:hover{
        background: #f2f2f2;
    }
     .leftmenu{
      left:0;
      background-color: peachpuff;
      width: 300px;
      margin-top: 0px;
      position: fixed;
      overflow-y: auto;
    }
       .smbtn{
      background-color: brown;
      width:60px;
      height: 30px;
      color:white;
      border:none;
      cursor: pointer;
    }
    .sb{
      position: fixed;
      background-color: peachpuff;
    }

	</style>
	<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $('.search-box input[type="text"]').on("keyup input", function(){
        /* Get input value on change */
        var inputVal = $(this).val();
        var resultDropdown = $(this).siblings(".result");
        if(inputVal.length){
            $.get("backend-search.php", {term: inputVal}).done(function(data){
                // Display the returned data in browser
                resultDropdown.html(data);
            });
        } else{
            resultDropdown.empty();
        }
    });
    
    // Set search input value on click of result item
    $(document).on("click", ".result p", function(){
        $(this).parents(".search-box").find('input[type="text"]').val($(this).text());
        $(this).parent(".result").empty();
    });
});
</script>
</head>
<body style="background-color: papayawhip;">
      <?php
      ob_start();
    $conn=mysqli_connect("localhost","id13073284_test","Prashant1!","id13073284_test");
    session_start();
    $username=$_SESSION['email'];
   
    if(empty($username))
    {
      header('location:Login.php');
    }
    $s="select * from inf where email='$username'";

    $re=mysqli_query($conn,$s);
      if(mysqli_num_rows($re)>0){
  
      while($ro=mysqli_fetch_assoc($re))
      { $n1=$ro['name'];
		$id1=$ro['aid'];
    $io1=$ro['image'];

		}}
   	$id2=$_SESSION['e2'];


      $s="select * from inf where aid='$id2'";
    $re=mysqli_query($conn,$s);
      if(mysqli_num_rows($re)>0){
  
      while($ro=mysqli_fetch_assoc($re))
      {
        $n2=$ro['name'];
       }}

        $i1="select image from inf where aid='$id1'";
         $res1=mysqli_query($conn,$i1);
         $rot1=mysqli_fetch_assoc($res1);
          $i2="select image from inf where aid='$id2'";
         $res2=mysqli_query($conn,$i2);
         $rot2=mysqli_fetch_assoc($res2);
?>
  <div class="menu">
      <button style="width:280px;"><?php echo $n; ?></button>
      <button onClick="blogs()">Home</button>
      <button onClick="time()">Timeline</button>
      <button onClick="pro()">Profile</button>      
      <button onClick="log()" style="float: right;">Logout</button>
      <button onClick="upro()" style="float: right;">Update Profile</button>
    </div>
    </form>
     <div class="leftmenu">
      <?php 
        if(empty($io1))
         echo '<center><img src="123.jpg" style="margin:22px;height:200px;width:200px;border-radius:100px;"/></center>';
        else
        echo '<center><img src="data:image/jpeg;base64,'.base64_encode( $io1 ).'" style="margin:22px;height:200px;width:200px;border-radius:100px;"/></center>';
      ?>
    </div>
        <center> 
     <div>    
      <center>  <div style="
  display:flex;
  flex-direction:column;
  width: 400px;
  margin-top: 44px;
  height:600px;
  background-color: papayawhip;
  "> <div class='head' style="margin-top: 50px;"><?php echo $n2; ?></div><center>
  <div style="overflow: auto;
  height:400px;
  background-color: white; 
  border-left: 1px solid black;   
  border-right: 1px solid black;   
  display: flex;
  flex-direction: column-reverse;
  margin-top: 0px;">
		<?php
		 $s1="select * from chat where (sender='$id1' and reciever='$id2') or (sender='$id2' and reciever='$id1') order by `mid` desc";
		
    $re1=mysqli_query($conn,$s1);
   
      if(mysqli_num_rows($re)>0){
  
      while($ro1=mysqli_fetch_assoc($re1))
      {
        $s=$ro1['sender'];
        $m1=$ro1['message'];
        
        ?>
   
        <table>
        <td style="float: left; width: 370px;border-bottom: 1px solid black"><?php 
        if($s==$id1){
        if(empty($rot1['image']))
            echo '<img src="123.jpg" style="height:40px;width:40px;float:right;border-radius:20px;"/>';
          else
        echo '<img src="data:image/jpeg;base64,'.base64_encode( $rot1['image'] ).'" style="height:40px;width:40px;float:right;border-radius:20px;"/>';
        echo "<h3 style='text-align:center;margin:0px;padding:0px;width:320px;float:left;height:auto;'>".$m1."</h3>";

       ?></td>
       	<?php }else
        {
          if(empty($rot2['image']))
            echo '<img src="123.jpg" style="height:40px;float:left;width:40px;border-radius:20px;"/>';
          else
          echo '<img src="data:image/jpeg;base64,'.base64_encode( $rot2['image'] ).'" style="height:40px;float:left;width:40px;border-radius:20px;"/>';
       echo "<h3 style='text-align:center;margin:0px;padding:0px;height:auto;width:320px;float:right;'>".$m1."</h3>";
    	}?>
       </table>
     
        <?php
       }
   		}
		?>
		</div>		
<form method="POST">
		<center><input style='height: 30px;border: 1px solid black;width: 294px;margin-top: 0px;' placeholder="type to chat.." type="text" name="message" required>
		<input style='height: 35px;border:none;width: 100px;background-color: brown;color: white;cursor: pointer;margin-bottom: 30px;' type="submit" name="submit5" value="Send"></center>
		</form>
		</center>
		<?php
		if(isset($_POST['submit5']))
		{
			$me=$_POST['message'];
			
			$s12="insert into chat(`sender` ,`reciever`, `message`) VALUES ('$id1','$id2','$me')";
      $s13="update `inf` set `not`=1 where aid='$id2'";
      mysqli_query($conn,$s13);
			$rs=mysqli_query($conn,$s12);
			if($rs)
			{
					?>
			<script>
			window.location.href = 'mess1.php';
			</script>
			<?php
			}
		}
		?>

	</div>

    </center> 

</div>   
</div>
<div class="birthday">
  
<div class="sb">
        <center><div class='head'>Search</div></center>
        <div class="search-box">
        <form action="1.php" method="POST">
        <input type="text" autocomplete="off" placeholder="Search your batchmates..." name="name" />
        <div class="result"></div>
        </div>
        <input class="smbtn" type='submit' value="Search">
        </form>
   
<div style="overflow-y: auto;height: 200px;"> 
  <div class="head">BIRTHDAY'S</div>
  <?php
  $mydate=getdate(date("U"));
$h=$mydate['mday']."-".$mydate['month'];
$bsql="select * from inf except (select * from inf where aid='$id1')";
$r=mysqli_query($conn,$bsql);
while($ro=mysqli_fetch_assoc($r))
{
  $na=$ro['name'];
  $ai=$ro['aid'];
  $d1=$ro['dob'];
 $str_arr = explode (" ", $d1);
  $g="".$str_arr[0]."-".$str_arr[1]."";
  if($g==$h)
  {?>
    <form method="POST">
          <?php
          if(empty($ro['image']))
         echo "<img src='123.jpg' style='height:150px;width:150px;border-radius:75px;margin:10px;'/>";
        else
        echo '<center><img src="data:image/jpeg;base64,'.base64_encode( $ro['image'] ).'" style="height:150px;width:150px;border-radius:75px;margin:10px;"/></center>';
          echo "<input type='hidden' name='a' value='$ai'>";
          echo "<input style='border:none;border-bottom:1px solid darkred;cursor:pointer;color:white;font-weight:bold;background-color:darksalmon;padding:5px;    font-size: 17px;
           font-style: italic;
           width:100%' type='submit' name='sub2' value='Wish $na'>";
        ?></form><?Php
        
  }
}
        if(isset($_POST['sub2']))
        {
          $s14=$_POST['a'];
         $_SESSION['e2']=$s14;
        header('location:mess1.php');
        }
        
        ?>
      </div>
     
<center><div class="head" style="margin-top: 10px;">NOTIFICATIONS</div></center>
<div style="overflow-y: auto;height: 250px;"> 
  <?php
    $s='select * from news';
    $r=mysqli_query($conn,$s);
    while($ro=mysqli_fetch_assoc($r)){
        echo '<center><img src="data:image/jpeg;base64,'.base64_encode( $ro['image'] ).'" style="height:150px;width:250px;margin:5px;"/></center>';
        echo '<center><div class="head">'.$ro['news'].'</div></center>';
    }
  ?>
</div>
 </div>
  

<div class='inbox'>
<center><div class='head'>Inbox</div></center>
<?php
     $s1="select distinct sender from chat where reciever='$id1' order by `mid` desc";
    
    $re1=mysqli_query($conn,$s1);
   
      if(mysqli_num_rows($re)>0){
  
      while($ro1=mysqli_fetch_assoc($re1))
      {
        $s2="select * from inf where aid=".$ro1['sender'];
       
          $re2=mysqli_query($conn,$s2);
   
      if(mysqli_num_rows($re2)>0){
        
      while($ro2=mysqli_fetch_assoc($re2))
       {
        $n3=$ro2['name'];
        $a=$ro2['aid'];
        ?>
       
         <form method="POST">
          <?php
          echo "<input type='hidden' name='a' value='$a'>";
          echo "<input style='border:none;border-bottom:1px solid darkred;cursor:pointer;color:white;font-weight:bold;background-color:darksalmon;padding:5px;    font-size: 17px;
           font-style: italic;
           width:100%' type='submit' name='sub' value='$n3'>";
       }
       } ?>
         
      </table>
 
      </form>
   
        
<?php
       }
      }
      if(isset($_POST['sub']))
      {
         $s14=$_POST['a'];
         $_SESSION['e2']=$s14;
        header('location:mess1.php');
      }
  ob_flush();
?>
</div>

</body>
</html>
<script>

  function log(){
  location.href="index.php";
}
function pro(){
  location.href="Profile.php";
}
function time(){
  location.href="Timeline.php";
}
function upro(){
  location.href="Update.php";
}
function contact(){
  location.href="contact.php";
}
</script>

