<?php
    ob_start();
    $conn=mysqli_connect("localhost","id13073284_test","Prashant1!","id13073284_test");
    session_start();
    $username=$_SESSION['email'];

    if(empty($username))
    {
      header('location:Login.php');
    }
    
    $s="select * from inf where email='$username'";
    $re=mysqli_query($conn,$s);
      if(mysqli_num_rows($re)>0){
  
      while($ro=mysqli_fetch_assoc($re))
      {
        $n=$ro["name"];
        $id1=$ro['aid'];
        $yr=$ro['passout'];
      }}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Timeline</title>
	<style>
		p{
			display: block;
    margin-block-start: 1em;
    margin-block-end: 1em;
    margin-inline-start: 0px;
    margin-inline-end: 0px;

		}
		#a1{
			display: inline-block;
		}
		.menu{
      top:0;
      left:0;
      margin: 0px;
      position: fixed;
      height: 7%;
      width: 100%;
			color:white;
			background-color: brown; 
		}
    .sb{
      margin-top: 36px;
      right:0;
      width: 300px;
      padding-bottom: 187px;
      position: fixed;
      background-color: peachpuff;
    }
    .inbox{
      left:0;
      bottom:0;
      background-color:peachpuff;
      width: 300px;
      height: 54%;
      position: fixed;
      overflow-y: auto;
    }
    .birthday{
      right:0;
      bottom:0;
      background-color:peachpuff;
      width: 300px;
      height: 53%;
      position: fixed;
      overflow-y: auto;
    }
    ::-webkit-scrollbar{
    display: none;
    }
    .leftmenu{
      left:0;
      background-color: peachpuff;
      width: 300px;
      margin-top: 36px;
      position: fixed;
      overflow-y: auto;
    }
    .blogimg{
      margin-left: 25px;
      height: 350px;
      width: 600px; 
    }
    .simg{
      height:50px;
      margin-top: 10px;
      margin-left:25px;
      width:50px;
      border-radius:25px;
    }
    .main{
      width: 57%;
      background-color:papayawhip; 
      overflow-y: auto;
      margin-top: 36px;
      margin-left: 292px;
      height: 93%;
      position: fixed;
      padding: 0px;
    }
    .blogcontent{
      overflow-y: hidden;
      align-content: center;
      background-color:lemonchiffon;
      border:1px solid darkred;
      padding: 10px;
      margin-left:25px;
      height: 60px;
      width: 575px;
      overflow: auto;
      font-size: 17px;
      font-style: italic;
      font-weight: bold;
    }
		button{
			background-color: brown;
			color:white;
      border: none;
			width: auto;
      margin: 5px;
			font-size: 16px;
      padding: 8px;
		}
		button:hover{
			background-color: red;
			cursor: pointer;
		}
   
    td{
      font-size: 17px;
      font-style: italic;
      font-weight: bold;
    }
		.search-box{
        width: 230px;
        position: relative;
        display: inline-block;
        font-size: 14px;
    }
    .head{
      background-color: indianred;
      color:white;
      padding: 5px;
      font-size: 17px;
      padding-left: 20px;
       font-weight: bold;
       position: relative;
    }
    .search-box input[type="text"]{
        height: 32px;
        width: 200px;
        padding: 5px 10px;
        border: 1px solid #CCCCCC;
        font-size: 14px;
    }
    .result{
        position: absolute;        
        z-index: 999;
        top: 100%;
        left: 0;
        background-color: white;
    }
    .search-box input[type="text"], .result{
        width: 100%;
        color: black;
        box-sizing: border-box;
    }
    /* Formatting result items */
    .result p{
        margin: 0;
        padding: 7px 10px;
        border: 1px solid #CCCCCC;
        border-top: none;
        cursor: pointer;
    }
    .minbox{
    width: 100%;
     font-size: 17px;
      font-style: italic;
      font-weight: bold;
      background-color: darksalmon;
      border: none;
      border-bottom: 1px solid brown;
      color: white;
      height: 30px;
    }
    .minbox:hover{
      cursor: pointer;
      background-color: darkred;
    }
     .result p:hover{
        background: #f2f2f2;
    }
    .smbtn{
      background-color: brown;
      width:60px;
      height: 30px;
      color:white;
      border:none;
    }

	</style>
		<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $('.search-box input[type="text"]').on("keyup input", function(){
        /* Get input value on change */
        var inputVal = $(this).val();
        var resultDropdown = $(this).siblings(".result");
        if(inputVal.length){
            $.get("backend-search.php", {term: inputVal}).done(function(data){
                // Display the returned data in browser
                resultDropdown.html(data);
            });
        } else{
            resultDropdown.empty();
        }
    });
    
    // Set search input value on click of result item
    $(document).on("click", ".result p", function(){
        $(this).parents(".search-box").find('input[type="text"]').val($(this).text());
        $(this).parent(".result").empty();
    });
});
</script>
</head>
<body>
	<div class="menu">
      <button style="width:280px;"><?php echo $n; ?></button>
      <button onClick="blogs()">Home</button>
      <button onClick="time()">Timeline</button>
      <button onClick="pro()">Profile</button>      
      <button onClick="log()" style="float: right;">Logout</button>
      <button onClick="upro()" style="float: right;">Update Profile</button>
    </div>
  <div class="leftmenu">
    <?php 
    $uid2=$_SESSION['e2'];
    $ss="select * from inf where aid='$uid2'";
    $rr=mysqli_query($conn,$ss);
    while ($rol=mysqli_fetch_assoc($rr)) {
      $nn=$rol['name'];
      $ii=$rol['image'];
    }?>

     <center><div class="head"><?php echo $nn; ?>'s Timeline</div></center>
    <?php if(empty($ii))
         echo '<center><img src="123.jpg" style="margin:15px;height:180px;width:180px;border-radius:90px;"/></center>';
        else
        echo '<center><img src="data:image/jpeg;base64,'.base64_encode( $ii ).'" style="margin:15px;height:180px;width:180px;border-radius:90px;"/></center>';
  ?>
 
  </div>

    <div class='main'>
<?php

    $uid2=$_SESSION['e2'];
    $s="select * from blogs where flag=1 and aid='$uid2' order by bid desc";
    $re=mysqli_query($conn,$s);
      if(mysqli_num_rows($re)>0){
  
      while($ro=mysqli_fetch_assoc($re))
      {
        $c=$ro["blog"];
        $n=$ro["aid"];
        $t=$ro['time'];
        $t=explode(" ", $t);
        $t=explode("-",$t[0]);
        $t=$t[2]."/".$t[1]."/".$t[0];
        $sq="select * from inf where aid='$n'";
         $res=mysqli_query($conn,$sq);
         $rot=mysqli_fetch_assoc($res);
         
       

        if(empty($rot['image']))
        echo '<img src="123.jpg" class="simg"';
        else
        echo '<img src="data:image/jpeg;base64,'.base64_encode( $rot['image'] ).'" class="simg"/>';
        
        ?></td><td><?php echo "<h2 style='display:inline-block;padding-left:15px;'>".$rot['name']."</h2>"; ?><?php echo "<p style='float:right;margin-right:155px;'>".$t."</p>"; ?></td></tr>
        
        <tr><td><?php if(empty($ro['image']))
        echo "";
        else echo '<img src="data:image/jpeg;base64,'.base64_encode( $ro['image'] ).'" class="blogimg"/>'; ?></td></tr>
        </td>
        <tr><td><?php echo "<p class='blogcontent'>".$c."</p>";  ?></td></tr>
        <tr><td><?php echo "________________________________________________________________________________________________<br>";}}
        else
          echo "<center><h3>Your friend hasn't posted anything yet....!!</h3></center>";
        ?></td></tr>

    

     </div>

<div class="sb">
        <center><div class='head'>Search</div></center>
        <div class="search-box">
        <form action="1.php" method="POST">
        <input type="text" autocomplete="off" placeholder="Search your batchmates..." name="name" />
        <div class="result"></div>
        </div>
        <input class="smbtn" type='submit' value="Search">
        </form>
    <div class="head">BIRTHDAY'S</div> 
<div style="overflow-y: auto;height: 160px;"> 

  <?php
  $mydate=getdate(date("U"));
$h=$mydate['mday']."-".$mydate['month'];
$bsql="select * from inf except (select * from inf where aid='$id1')";
$r=mysqli_query($conn,$bsql);
while($ro=mysqli_fetch_assoc($r))
{
  $na=$ro['name'];
  $ai=$ro['aid'];
  $d1=$ro['dob'];
 $str_arr = explode (" ", $d1);
  $g="".$str_arr[0]."-".$str_arr[1]."";
  if($g==$h)
  {?>
    <form method="POST">
          <?php
          if(empty($ro['image']))
         echo "<img src='123.jpg' style='height:150px;width:150px;border-radius:75px;margin:10px;'/>";
        else
        echo '<center><img src="data:image/jpeg;base64,'.base64_encode( $ro['image'] ).'" style="margin:10px;height:150px;width:150px;border-radius:75px;"/></center>';
          echo "<input type='hidden' name='a' value='$ai'>";
          echo "<input class='minbox' style='margin-bottom:10px;' type='submit' name='sub2' value='Wish $na'>";
        ?></form><?Php
        
  }
}
        if(isset($_POST['sub2']))
        {
          $s14=$_POST['a'];
         $_SESSION['e2']=$s14;
        header('location:mess1.php');
        }
        
        ?>
      </div>

<div class='inbox'>
<center><div class='head'>Inbox</div></center>
<?php
    $color=1;
     $s1="select distinct sender from chat where reciever='$id1' order by `mid` desc";
    
    $re1=mysqli_query($conn,$s1);
   
      if(mysqli_num_rows($re)>0){
  
      while($ro1=mysqli_fetch_assoc($re1))
      {
        $s2="select * from inf where aid=".$ro1['sender'];
       
          $re2=mysqli_query($conn,$s2);
   
      if(mysqli_num_rows($re2)>0){
        
      while($ro2=mysqli_fetch_assoc($re2))
       {
        $n3=$ro2['name'];
        $a=$ro2['aid'];
        ?>
       
         <form method="POST">
          <?php
          echo "<input type='hidden' name='a' value='$a'>";
          echo "<input class='minbox' type='submit' name='sub' value='$n3'>";
       }
       } ?>
         
      </table>
 
      </form>
   
        
<?php
       }
      }
      if(isset($_POST['sub']))
      {
         $s14=$_POST['a'];
         $_SESSION['e2']=$s14;
        header('location:mess1.php');
      }
  ob_flush();
?>
</div>

<div class="birthday">


             
     
<center><div class="head" style="margin-top: 10px;">NOTIFICATIONS</div></center>
<div style="overflow-y: auto;height: 250px;"> 
  <?php
    $s='select * from news';
    $r=mysqli_query($conn,$s);
    while($ro=mysqli_fetch_assoc($r)){
        echo '<center><img src="data:image/jpeg;base64,'.base64_encode( $ro['image'] ).'" style="height:150px;width:250px;margin:5px;"/></center>';
        echo '<center><div class="head">'.$ro['news'].'</div></center>';
    }
  ?>
</div>
 </div>
  

</div>   
  
	

</body>
</html>
<script>


  function log(){
  location.href="index.php";
}
function pro(){
  location.href="Profile.php";
}
function time(){
  location.href="Timeline.php";
}
function upro(){
  location.href="Update.php";
}
function contact(){
  location.href="contact.php";
}
</script>
